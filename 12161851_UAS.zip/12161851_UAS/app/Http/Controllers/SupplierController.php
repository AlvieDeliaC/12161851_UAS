<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Supplier; // 1

class SupplierController extends Controller
{
    //
    public function index()
    {
        $suppliers = Supplier::orderBy('created_at', 'DESC')->get(); // 2
        // CODE DIATAS SAMA DENGAN > select * from `suppliers` order by `created_at` desc 
        return view('suppliers.index', compact('suppliers')); // 3
    }
    
    public function create()
    {
        return view('suppliers.create');
    }

    
    public function save(Request $request)
    {
        //MELAKUKAN VALIDASI DATA YANG DIKIRIM DARI FORM INPUTAN
        $this->validate($request, [
            'name' => 'required|string|',
            'store' => 'required|string'
        ]);

        try {
            //MENYIMPAN DATA KEDALAM DATABASE
            $supplier = Supplier::create([
                'name' => $request->name,
                'store' => $request->store,
            ]);
            
            //REDIRECT KEMBALI KE HALAMAN /supplier DENGAN FLASH MESSAGE SUCCESS
            return redirect('/supplier')->with(['success' => '<strong>' . $supplier->name . '</strong> Telah disimpan']);
        } catch(\Exception $e) {
            //APABILA TERDAPAT ERROR MAKA REDIRECT KE FORM INPUT
            //DAN MENAMPILKAN FLASH MESSAGE ERROR
            return redirect('/supplier/new')->with(['error' => $e->getMessage()]);
        }
    }

    public function edit($id)
    {
        $supplier = Supplier::find($id); // Query ke database untuk mengambil data dengan id yang diterima
        return view('suppliers.edit', compact('supplier'));
    }

    public function update(Request $request, $id)
    {
    $supplier = Supplier::find($id); // QUERY UNTUK MENGAMBIL DATA BERDASARKAN ID
    //KEMUDIAN MENGUPDATE DATA TERSEBUT
    $supplier->update([
        'name' => $request->name,
        'store' => $request->store
    ]);
    //LALU DIARAHKAN KE HALAMAN /supplier DENGAN FLASH MESSAGE SUCCESS
    return redirect('/supplier')->with(['success' => '<strong>' . $supplier->name . '</strong> Diperbaharui']);
    }

    public function destroy($id)
{
    $supplier = Supplier::find($id); //QUERY KEDATABASE UNTUK MENGAMBIL DATA BERDASARKAN ID
    $supplier->delete(); // MENGHAPUS DATA YANG ADA DIDATABASE
    return redirect('/supplier')->with(['success' => '</strong>' . $supplier->name . '</strong> Dihapus']); // DIARAHKAN KEMBALI KEHALAMAN /product
}
}
