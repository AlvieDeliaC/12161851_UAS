
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Invoice App - Register</title>
	<link href="./assets/./assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="./assets/./assets/css/datepicker3.css" rel="stylesheet">
	<link href="./assets/./assets/css/styles.css" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<div class="row">
	@yield('content')
	</div><!-- /.row -->	
	

<script src="./asset/./asset/js/jquery-1.11.1.min.js"></script>
	<script src="./asset/./asset/js/bootstrap.min.js"></script>
</body>
</html>
