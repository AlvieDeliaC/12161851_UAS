<?php $__env->startSection('content'); ?>
    <div class="card o-hidden border-0 shadow-lg my-5">
      <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
          <div class="col-lg-5 d-none d-lg-block bg-register-image"></div>
          <div class="col-lg-7">
            <div class="p-5">
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">Create an Account!</h1>
              </div>
              <form  method="POST" action="<?php echo e(route('register')); ?>">
              <?php echo csrf_field(); ?>
                  <div class="form-group">
                    <input type="text" class="form-control form-control-user<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>"
                    id="exampleFirstName" placeholder="Name" required>
                    <?php if($errors->has('name')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        /span>
                    <?php endif; ?>
                  </div>
                  <div class="form-group">
                    <input type="text" class="form-control form-control-user<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" 
                    id="exampleInputEmail" placeholder="Email Address" required>
                    <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
                <div class="form-group row">
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <input type="password" class="form-control form-control-user<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password"
                        id="exampleInputPassword" placeholder="Password"  required>
                        <?php if($errors->has('password')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="col-sm-6">
                        <input type="password" class="form-control form-control-user" name="password_confirmation" id="password-confirm" placeholder="Repeat Password">
                    </div>
                </div>
                <button class="btn btn-primary btn-user btn-block" type="submit">
                Register
                </button>
              </form>
              <hr>
              <div class="text-center">
                <a class="small" href="<?php echo e(route('password.request')); ?>">Forgot Password?</a>
              </div>
              <div class="text-center">
                <a class="small" href="<?php echo e(route('login')); ?>">Already have an account? Login!</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('auth.main1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>