    <link href="../assets/./assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="../assets/./assets/css/font-awesome.min.css" rel="stylesheet">
	<link href="../assets/./assets/css/datepicker3.css" rel="stylesheet">
	<link href="../assets/./assets/css/styles.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
    
	<script src="../assets/./assets/js/jquery-1.11.1.min.js"></script>
	<script src="../assets/./assets/js/bootstrap.min.js"></script>
	<script src="../assets/./assets/js/chart.min.js"></script>
	<script src="../assets/./assets/js/chart-data.js"></script>
	<script src="../assets/./assets/js/easypiechart.js"></script>
	<script src="../assets/./assets/js/easypiechart-data.js"></script>
	<script src="../assets/./assets/js/bootstrap-datepicker.js"></script>
	<script src="../assets/./assets/js/custom.js"></script>
	<script>
		window.onload = function () {
	var chart1 = document.getElementById("line-chart").getContext("2d");
	window.myLine = new Chart(chart1).Line(lineChartData, {
	responsive: true,
	scaleLineColor: "rgba(0,0,0,.2)",
	scaleGridLineColor: "rgba(0,0,0,.05)",
	scaleFontColor: "#c5c7cc"
	});
};
	</script>
  


<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-11">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Update Product</h3>
                    </div>
                    <div class="card-body">
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>
						
                        <!-- ACTION MENGARAH KE /product/id -->
                        <form action="<?php echo e(url('/product/' . $product->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <!-- KARENA METHOD YANG AKAN DIGUNAKAN ADALAH PUT -->
                            <!-- MAKA KITA PERLU MENGIRIMKAN PARAMETER DENGAN NAME _method -->
                            <!-- DAN VALUE PUT -->
                            <input type="hidden" name="_method" value="PUT" class="form-control">
                            <div class="form-group">
                                <label for="">Name</label>
                                <input type="text" name="title" class="form-control" value="<?php echo e($product->title); ?>" placeholder="Masukkan nama produk">
                            </div>
                            <div class="form-group">
                                <label for="">Description</label>
                                <textarea name="description" cols="10" rows="10" class="form-control"><?php echo e($product->description); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label for="">Price</label>
                                <input type="number" name="price" class="form-control" value="<?php echo e($product->price); ?>">
                            </div>
                            <div class="form-group">
                                <label for="">Stock</label>
                                <input type="number" name="stock" class="form-control" value="<?php echo e($product->stock); ?>">
                            </div>
                            <div class="form-group">
                                <button class="btn btn-primary btn-sm">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>