<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
			<div class="login-panel panel panel-default">
				<div class="panel-heading">Log in</div>
				<div class="panel-body">
					<form role="form" method="POST" action="<?php echo e(route('login')); ?>">
					<?php echo csrf_field(); ?>
						<fieldset>
							<div class="form-group">
								<input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"  value="<?php echo e(old('email')); ?>" required placeholder="E-mail" name="email" type="email" autofocus="">
								<?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
							</div>
							<div class="form-group">
								<input class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" required placeholder="Password" name="password" type="password" value="">
								<?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
							</div>
							<div class="checkbox">
								<label>
									<input name="remember" type="checkbox" value="Remember Me">Remember Me
								</label>
							</div>
							<button type="submit" class="btn btn-primary btn-lg btn-block">
                                    <?php echo e(__('Login')); ?>

                            </button></fieldset>
					</form>
				</div>
			</div>
		</div><!-- /.col-->
	</div><!-- /.row -->	
<?php $__env->stopSection(); ?>	

<?php echo $__env->make('auth.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>